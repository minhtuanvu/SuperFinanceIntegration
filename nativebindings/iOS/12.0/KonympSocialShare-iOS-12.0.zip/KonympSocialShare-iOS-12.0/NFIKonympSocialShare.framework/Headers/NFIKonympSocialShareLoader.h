#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIKonympSocialShareModules(JSContext* context);
JSValue* extractNFIKonympSocialShareStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIKonympSocialShareStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
