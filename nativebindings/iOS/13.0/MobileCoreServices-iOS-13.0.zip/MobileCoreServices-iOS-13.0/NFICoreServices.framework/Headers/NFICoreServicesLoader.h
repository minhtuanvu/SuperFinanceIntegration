#import <JavaScriptCore/JavaScriptCore.h>

void loadNFICoreServicesModules(JSContext* context);
JSValue* extractNFICoreServicesStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFICoreServicesStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
