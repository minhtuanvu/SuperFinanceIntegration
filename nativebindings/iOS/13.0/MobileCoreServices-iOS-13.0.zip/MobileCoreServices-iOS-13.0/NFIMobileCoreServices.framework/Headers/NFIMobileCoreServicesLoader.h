#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIMobileCoreServicesModules(JSContext* context);
JSValue* extractNFIMobileCoreServicesStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIMobileCoreServicesStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
