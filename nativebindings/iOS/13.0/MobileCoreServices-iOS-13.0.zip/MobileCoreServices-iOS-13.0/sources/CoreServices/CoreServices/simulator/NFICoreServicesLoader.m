#import "allincludes.h"
#import <JavaScriptCore/JavaScriptCore.h>
void loadNFICoreServicesModules(JSContext* context)
{
	load_CoreServices_UTType_symbols(context);
	load_CoreServices_UTCoreTypes_symbols(context);
}

JSValue* extractNFICoreServicesStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context)
{
    
    return nil;
}

BOOL setNFICoreServicesStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation)
{
    
    return NO;
}

