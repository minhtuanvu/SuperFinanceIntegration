#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
	context[@"UTTypeIsDynamic"] = ^Boolean(id arg0) {
		return UTTypeIsDynamic(arg0);
	};
	context[@"UTTypeConformsTo"] = ^Boolean(id arg0, id arg1) {
		return UTTypeConformsTo(arg0, arg1);
	};
	context[@"UTTypeCreatePreferredIdentifierForTag"] = ^id(id arg0, id arg1, id arg2) {
		return UTTypeCreatePreferredIdentifierForTag(arg0, arg1, arg2);
	};
	context[@"UTTypeCopyDeclaringBundleURL"] = ^id(id arg0) {
		return UTTypeCopyDeclaringBundleURL(arg0);
	};
	context[@"UTTypeEqual"] = ^Boolean(id arg0, id arg1) {
		return UTTypeEqual(arg0, arg1);
	};
	context[@"UTTypeCopyAllTagsWithClass"] = ^id(id arg0, id arg1) {
		return UTTypeCopyAllTagsWithClass(arg0, arg1);
	};
	context[@"UTTypeIsDeclared"] = ^Boolean(id arg0) {
		return UTTypeIsDeclared(arg0);
	};
	context[@"UTTypeCopyDeclaration"] = ^id(id arg0) {
		return UTTypeCopyDeclaration(arg0);
	};
	context[@"UTTypeCopyDescription"] = ^id(id arg0) {
		return UTTypeCopyDescription(arg0);
	};
	context[@"UTTypeCopyPreferredTagWithClass"] = ^id(id arg0, id arg1) {
		return UTTypeCopyPreferredTagWithClass(arg0, arg1);
	};
	context[@"UTTypeCreateAllIdentifiersForTag"] = ^id(id arg0, id arg1, id arg2) {
		return UTTypeCreateAllIdentifiersForTag(arg0, arg1, arg2);
	};
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &kUTTagClassMIMEType;
	if (p != NULL) context[@"kUTTagClassMIMEType"] = [JSValue valueWithObject: (__bridge id) kUTTagClassMIMEType inContext: context];
	p = (void*) &kUTTypeReferenceURLKey;
	if (p != NULL) context[@"kUTTypeReferenceURLKey"] = [JSValue valueWithObject: (__bridge id) kUTTypeReferenceURLKey inContext: context];
	p = (void*) &kUTTypeIconFileKey;
	if (p != NULL) context[@"kUTTypeIconFileKey"] = [JSValue valueWithObject: (__bridge id) kUTTypeIconFileKey inContext: context];
	p = (void*) &kUTTypeIdentifierKey;
	if (p != NULL) context[@"kUTTypeIdentifierKey"] = [JSValue valueWithObject: (__bridge id) kUTTypeIdentifierKey inContext: context];
	p = (void*) &kUTTagClassFilenameExtension;
	if (p != NULL) context[@"kUTTagClassFilenameExtension"] = [JSValue valueWithObject: (__bridge id) kUTTagClassFilenameExtension inContext: context];
	p = (void*) &kUTTypeConformsToKey;
	if (p != NULL) context[@"kUTTypeConformsToKey"] = [JSValue valueWithObject: (__bridge id) kUTTypeConformsToKey inContext: context];
	p = (void*) &kUTImportedTypeDeclarationsKey;
	if (p != NULL) context[@"kUTImportedTypeDeclarationsKey"] = [JSValue valueWithObject: (__bridge id) kUTImportedTypeDeclarationsKey inContext: context];
	p = (void*) &kUTTypeVersionKey;
	if (p != NULL) context[@"kUTTypeVersionKey"] = [JSValue valueWithObject: (__bridge id) kUTTypeVersionKey inContext: context];
	p = (void*) &kUTExportedTypeDeclarationsKey;
	if (p != NULL) context[@"kUTExportedTypeDeclarationsKey"] = [JSValue valueWithObject: (__bridge id) kUTExportedTypeDeclarationsKey inContext: context];
	p = (void*) &kUTTypeDescriptionKey;
	if (p != NULL) context[@"kUTTypeDescriptionKey"] = [JSValue valueWithObject: (__bridge id) kUTTypeDescriptionKey inContext: context];
	p = (void*) &kUTTypeTagSpecificationKey;
	if (p != NULL) context[@"kUTTypeTagSpecificationKey"] = [JSValue valueWithObject: (__bridge id) kUTTypeTagSpecificationKey inContext: context];
}
void load_CoreServices_UTType_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
