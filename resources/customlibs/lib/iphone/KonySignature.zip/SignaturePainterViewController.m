//
//  SignaturePainterViewController.m
//  KonySignature
//
//  Created by adan on 25.07.13.
//  Copyright (c) 2013 Softserve. All rights reserved.
//

#import "SignaturePainterViewController.h"

@interface SignaturePainterViewController ()

@end

@implementation SignaturePainterViewController

- (void)loadView {
    SignaturePainterView *aView = [[SignaturePainterView alloc] init];
    self.view = aView;
    self->_painterView = aView;
    aView.vc = self;
    [aView release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelTouched:)];
	self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneTouched:)];
    self.navigationItem.rightBarButtonItem = rightItem;
    [self.navigationItem.rightBarButtonItem setEnabled:NO];
    [rightItem release];    
    
    self.painterView.strokeWidth         = self.strokeWidth;
    self.painterView.strokeColor         = self.strokeColor;
    self.painterView.showClearButton     = self.showClearButton;
    self.painterView.shakeToClearEnabled = self.shakeToClearEnabled;
}

- (void)dealloc {
    self.strokeColor = nil;
    [super dealloc];
}

- (void)cancelTouched:(id)sender {
    if ([self.delegate respondsToSelector:@selector(signaturePainterDidCancel:)]) {
        [self.delegate signaturePainterDidCancel:self];
    }
}

- (void)doneTouched:(id)sender {
    if ([self.delegate respondsToSelector:@selector(signaturePainterDidFinishDrawing:)]) {
        [self.delegate signaturePainterDidFinishDrawing:self];
    }
}

@end
