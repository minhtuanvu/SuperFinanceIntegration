//
//  UIColor+HexString.h
//  KonySignature
//
//  Created by adan on 25.07.13.
//  Copyright (c) 2013 Softserve. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (HexString)
+ (UIColor *)colorWithHexString:(NSString *)stringToConvert;
@end
