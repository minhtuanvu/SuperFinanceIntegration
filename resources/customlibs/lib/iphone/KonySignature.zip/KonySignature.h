//
//  KonySignature.h
//  KonySignature
//
//  Created by adan on 25.07.13.
//  Copyright (c) 2013 Softserve. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CallBack;

typedef enum {
    KonySignatureResultOk = 0
} KonySignatureResult;

@interface KonySignature : NSObject
+ (NSInteger)presentSignanurePainterWithTitle:(NSString *)title
                                  strokeWidth:(CGFloat)strokeWidth
                                  strokeColor:(NSString *)hexColor
                               showClearButon:(BOOL)showClearButon
                         shakeToCancelEnabled:(BOOL)shakeToCancelEnabled
                                     callback:(CallBack *)callback;
@end
