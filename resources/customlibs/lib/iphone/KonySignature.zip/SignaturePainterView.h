//
//  SignaturePainterView.h
//  KonySignature
//
//  Created by adan on 25.07.13.
//  Copyright (c) 2013 Softserve. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignaturePainterView : UIView
@property(nonatomic,assign) CGFloat                     strokeWidth;
@property(nonatomic,assign) NSString                    *strokeColor;
@property(nonatomic,assign) BOOL                        showClearButton;   //If YES clear button to clear, else if NO long tap to clear
@property(nonatomic,assign) BOOL                        shakeToClearEnabled;
@property(nonatomic,assign) UIViewController* vc;
- (UIImage*) getSignatureImage;
- (NSString*) getSignatureImageBase64;
@end
